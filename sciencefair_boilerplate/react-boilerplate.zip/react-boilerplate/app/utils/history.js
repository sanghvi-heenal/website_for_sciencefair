import createHistory from 'history/createBrowserHistory';
const history = createHistory();
export default history;
